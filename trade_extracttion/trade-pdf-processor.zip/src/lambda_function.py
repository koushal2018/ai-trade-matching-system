import json
import boto3
import base64
import os
import logging
from datetime import datetime
from decimal import Decimal  # <--- Make sure this import is here!

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Hardcoded schema - can alternatively be loaded from S3
TRADE_ATTRIBUTES_SCHEMA = {
  "trade_matching_attributes": {
    "primary_identifiers": {
      "fields": [
        "global_uti",
        "trade_id",
        "internal_reference"
      ]
    },
    "economic_terms": {
      "dates": {
        "fields": [
          "trade_date",
          "effective_date",
          "termination_date"
        ]
      },
      "quantities": {
        "fields": [
          "total_notional_quantity",
          "unit_of_measure"
        ]
      },
      "pricing": {
        "fields": [
          "fixed_price",
          "currency",
          "price_unit"
        ]
      }
    },
    "product_details": {
      "fields": [
        "commodity_type",
        "settlement_type",
        "business_days_convention"
      ]
    },
    "counterparty_information": {
      "fields": [
        "buyer_legal_entity",
        "seller_legal_entity"
      ]
    },
    "validation_rules": {
      "required_matches": [
        "global_uti",
        "trade_date",
        "effective_date",
        "termination_date",
        "total_notional_quantity",
        "fixed_price",
        "commodity_type"
      ],
      "tolerance_checks": {
        "trade_date": "exact_match",
        "quantities": "exact_match",
        "prices": "exact_match"
      }
    }
  }
}

def load_field_schema():
    """Extract fields from the schema"""
    schema = TRADE_ATTRIBUTES_SCHEMA
    fields = []
    
    for category, content in schema['trade_matching_attributes'].items():
        if category == 'validation_rules':
            continue
        if 'fields' in content:
            fields.extend(content['fields'])
        else:
            for subcategory, subdata in content.items():
                if isinstance(subdata, dict) and 'fields' in subdata:
                    fields.extend(subdata['fields'])
    
    logger.info(f"Loaded {len(fields)} fields from schema")
    return fields

def extract_with_bedrock_vision(bucket, key, required_fields):
    """Use Bedrock Claude vision directly on S3 PDF"""
    bedrock = boto3.client('bedrock-runtime', region_name='us-west-2')
    
    # Get PDF from S3
    s3 = boto3.client('s3')
    pdf_obj = s3.get_object(Bucket=bucket, Key=key)
    pdf_bytes = pdf_obj['Body'].read()
    
    # Prepare message for Claude
    message = {
        "role": "user",
        "content": [
            {
                "type": "document",
                "source": {
                    "type": "base64",
                    "media_type": "application/pdf",
                    "data": base64.b64encode(pdf_bytes).decode('utf-8')
                }
            },
            {
                "type": "text", 
                "text": f"""Extract trade data from this PDF and return ONLY a valid JSON object.

Required fields: {', '.join(required_fields)}

Return only the JSON object with these exact field names."""
            }
        ]
    }
    
    # Call Bedrock
    response = bedrock.invoke_model(
        modelId="anthropic.claude-3-5-sonnet-20241022-v2:0",
        body=json.dumps({
            "anthropic_version": "bedrock-2023-05-31",
            "max_tokens": 4000,
            "messages": [message]
        })
    )
    
    result = json.loads(response['body'].read())
    return result['content'][0]['text']

def determine_source_from_path(bucket, key):
    """Determine if the document is from Bank or Counterparty based on S3 path."""
    path = f"{bucket}/{key}".lower()
    
    if '/bank/' in path:
        return 'BANK'
    elif '/counterparty/' in path:
        return 'COUNTERPARTY'
    else:
        return 'UNKNOWN'

def convert_float_to_decimal(obj):
    """Convert float values to Decimal recursively in a dictionary."""
    if isinstance(obj, dict):
        return {k: convert_float_to_decimal(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [convert_float_to_decimal(i) for i in obj]
    elif isinstance(obj, float):
        return Decimal(str(obj))
    else:
        return obj

def save_to_dynamodb(trade_data, source_type):
    """Save the trade data to the appropriate DynamoDB table."""
    # Determine table name based on source
    if source_type == 'BANK':
        table_name = os.environ.get('BANK_TABLE', 'BankTradeData')
    else:  # COUNTERPARTY or fallback
        table_name = os.environ.get('COUNTERPARTY_TABLE', 'CounterpartyTradeData')
    
    # Add source information to the data
    trade_data['source'] = source_type
    
    try:
        # Add metadata
        trade_data["processing_timestamp"] = datetime.now().isoformat()
        trade_data["matched_status"] = "PENDING"
        trade_data["last_updated"] = datetime.now().isoformat()
        
        # Convert all floats to Decimals for DynamoDB
        decimal_data = convert_float_to_decimal(trade_data)
        
        # Save to DynamoDB
        dynamodb = boto3.resource('dynamodb')
        table = dynamodb.Table(table_name)
        table.put_item(Item=decimal_data)
        
        logger.info(f"Successfully saved trade {decimal_data.get('trade_id')} to {table_name}")
        
        return {
            "status": "success",
            "message": f"Data saved to {table_name}",
            "trade_id": decimal_data.get('trade_id'),
            "table": table_name
        }
    except Exception as e:
        logger.error(f"Error saving to DynamoDB: {e}")
        return {
            "status": "error",
            "message": str(e)
        }

def lambda_handler(event, context):
    """AWS Lambda handler"""
    try:
        # Extract bucket and key from S3 event
        if 'Records' in event and event['Records'][0].get('eventSource') == 'aws:s3':
            bucket = event['Records'][0]['s3']['bucket']['name']
            key = event['Records'][0]['s3']['object']['key']
            logger.info(f"Processing PDF from S3 event: s3://{bucket}/{key}")
        else:
            # Handle direct invocation
            bucket = event.get('bucket')
            key = event.get('key')
            
            if not bucket or not key:
                return {
                    'statusCode': 400,
                    'body': json.dumps('Bucket and key parameters are required')
                }
            logger.info(f"Processing PDF from direct invocation: s3://{bucket}/{key}")
        
        # Skip if not a PDF
        if not key.lower().endswith('.pdf'):
            logger.info(f"Skipping non-PDF file: {key}")
            return {
                'statusCode': 200,
                'body': json.dumps('Skipped non-PDF file')
            }
        
        # Determine source type
        source_type = determine_source_from_path(bucket, key)
        logger.info(f"Determined source type: {source_type}")
        
        if source_type == 'UNKNOWN':
            logger.warning(f"Could not determine source type for {bucket}/{key}")
            return {
                'statusCode': 400,
                'body': json.dumps('Could not determine if document is from Bank or Counterparty')
            }
        
        # Load schema
        required_fields = load_field_schema()
        
        # Extract data from PDF
        logger.info(f"Extracting data from PDF at {bucket}/{key}")
        extracted_text = extract_with_bedrock_vision(bucket, key, required_fields)
        
        # Parse JSON from response
        try:
            extracted_data = json.loads(extracted_text)
        except json.JSONDecodeError:
            # Handle case where Claude didn't return proper JSON
            logger.error(f"Claude didn't return valid JSON. Raw output: {extracted_text[:200]}...")
            
            # Try to find JSON in the response
            import re
            json_pattern = r'(\{.*\})'
            match = re.search(json_pattern, extracted_text, re.DOTALL)
            
            if match:
                try:
                    extracted_data = json.loads(match.group(1))
                    logger.info("Successfully extracted JSON from Claude's response")
                except:
                    return {
                        'statusCode': 500,
                        'body': json.dumps('Failed to parse JSON from Claude response')
                    }
            else:
                return {
                    'statusCode': 500,
                    'body': json.dumps('Failed to find JSON in Claude response')
                }
        
        # Save extracted data to S3
        output_bucket = os.environ.get('OUTPUT_BUCKET', bucket)
        output_key = f"extracted/{source_type.lower()}/{key.split('/')[-1].replace('.pdf', '.json')}"
        
        s3 = boto3.client('s3')
        s3.put_object(
            Bucket=output_bucket,
            Key=output_key,
            Body=json.dumps(extracted_data, indent=2),
            ContentType="application/json"
        )
        
        logger.info(f"Extracted data saved to s3://{output_bucket}/{output_key}")
        
        # Save to DynamoDB
        db_result = save_to_dynamodb(extracted_data, source_type)
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Processing complete',
                'extractedDataLocation': f"s3://{output_bucket}/{output_key}",
                'sourceType': source_type,
                'dynamoDBResult': db_result
            }, indent=2)
        }
        
    except Exception as e:
        logger.error(f"Error processing document: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error: {str(e)}")
        }